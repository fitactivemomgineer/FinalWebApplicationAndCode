<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = 'chodges';
$dbpass = 'eTAIvFFnqeU9';
$dbname = 'presto';
?>
